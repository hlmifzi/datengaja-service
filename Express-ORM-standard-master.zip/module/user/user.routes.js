import express from "express"
import validate from "express-validation"
import { addUser, getAllUser, getUserByID, updateUser, deleteUser } from "./user.controller"
import userValidation from "../../middleware/validation/user.validation"

const router = express.Router()

router.get('/', getAllUser)
router.get('/:id', getUserByID)
router.post('/', addUser)
router.put('/:id', updateUser)
router.delete('/:id', deleteUser)

export default router