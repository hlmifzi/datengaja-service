import User from "../module/user/user.model"

import conn from "../config/datasource"

conn.sync({
  // force: true
})


export { User }
